import React from 'react'

const About = () => {
    return(
        <div>
            <h1>
                Tunnelx 
            </h1>
            <p>
                Tunnelx is student driven makerspace located in Koc University
            </p>
        </div>
    )
}

export default About;