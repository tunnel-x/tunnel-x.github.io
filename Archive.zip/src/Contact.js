import React from 'react'

const Contact = () => {
    return(
        <div>
            <h1>
                tunnelx@ku.edu.tr
            </h1>
        </div>
    )
}

export default Contact;