const API_URL = process.env.REACT_APP_API || 'http://localhost:4000';
export default API_URL;